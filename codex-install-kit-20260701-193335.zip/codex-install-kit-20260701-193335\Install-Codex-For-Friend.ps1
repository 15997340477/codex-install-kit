param(
    [string]$BaseUrl = "https://nexus.1982video.cn",
    [switch]$SkipStoreInstall,
    [switch]$InstallCliTools,
    [switch]$SkipWingetInstall
)

$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Assert-InKitRoot {
    $scriptRoot = Split-Path -Parent $PSCommandPath
    $payload = Join-Path $scriptRoot "payload"
    if (-not (Test-Path -LiteralPath $payload)) {
        throw "The payload folder was not found. Copy the whole install kit folder to this PC."
    }
    return $scriptRoot
}

$scriptRoot = Assert-InKitRoot
$payloadRoot = Join-Path $scriptRoot "payload"
$codexHome = Join-Path $env:USERPROFILE ".codex"
$skillsSrc = Join-Path $payloadRoot "skills"
$configTemplate = Join-Path $payloadRoot "codex-config-template.toml"
$configTarget = Join-Path $codexHome "config.toml"
$backupStamp = Get-Date -Format "yyyyMMdd-HHmmss"

Write-Host "Codex desktop config helper" -ForegroundColor Green
Write-Host "Current user: $env:USERNAME"
Write-Host "Codex config dir: $codexHome"
Write-Host "Proxy base URL: $BaseUrl"
Write-Host "Model: not preconfigured"

Write-Step "Checking PowerShell version"
if ($PSVersionTable.PSVersion.Major -lt 5) {
    throw "PowerShell is too old. Use Windows PowerShell 5 or PowerShell 7."
}

if (-not $SkipStoreInstall) {
    Write-Step "Installing Codex desktop app from Microsoft Store"
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        try {
            winget install --id OpenAI.Codex --source msstore --accept-package-agreements --accept-source-agreements
        } catch {
            Write-Warning "Store install command did not complete. If Codex is not installed, open Microsoft Store and search for OpenAI Codex."
        }
    } else {
        Write-Warning "winget was not found. Open Microsoft Store manually and search for OpenAI Codex."
    }
}

Write-Step "Checking Microsoft Store Codex app"
$storeCodex = Get-AppxPackage -Name "OpenAI.Codex" -ErrorAction SilentlyContinue
if ($storeCodex) {
    Write-Host "Found Store app: $($storeCodex.PackageFullName)"
} else {
    Write-Warning "OpenAI.Codex Store app was not found for this Windows user."
    Write-Warning "Manual install command: Start-Process `"ms-windows-store://pdp/?PFN=OpenAI.Codex_2p2nqsd0c76g0`""
}

if ($InstallCliTools -and -not $SkipWingetInstall) {
    Write-Step "Installing optional CLI tools with winget"
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        try {
            winget install --id Git.Git -e --source winget --accept-package-agreements --accept-source-agreements
        } catch {
            Write-Warning "Git install did not complete. It may already be installed, or winget may be restricted."
        }
        try {
            winget install --id OpenJS.NodeJS.LTS -e --source winget --accept-package-agreements --accept-source-agreements
        } catch {
            Write-Warning "Node.js install did not complete. It may already be installed, or winget may be restricted."
        }
        try {
            winget install --id OpenAI.Codex -e --source winget --accept-package-agreements --accept-source-agreements
        } catch {
            Write-Warning "Codex CLI winget install did not complete. This is optional for the desktop app setup."
        }
    } else {
        Write-Warning "winget was not found. Skipping optional CLI tools."
    }
} else {
    Write-Step "Skipping CLI dependency installation"
    Write-Host "This script now configures the Codex desktop app only."
}

Write-Step "Creating Codex config directory"
New-Item -ItemType Directory -Force -Path $codexHome | Out-Null

Write-Step "Backing up old config"
if (Test-Path -LiteralPath $configTarget) {
    Copy-Item -LiteralPath $configTarget -Destination "$configTarget.backup-$backupStamp" -Force
    Write-Host "Backed up: $configTarget.backup-$backupStamp"
}
if (Test-Path -LiteralPath (Join-Path $codexHome "skills")) {
    Rename-Item -LiteralPath (Join-Path $codexHome "skills") -NewName "skills.backup-$backupStamp"
    Write-Host "Backed up old skills folder: skills.backup-$backupStamp"
}

Write-Step "Writing Codex proxy config"
$config = Get-Content -LiteralPath $configTemplate -Raw
$config = $config.Replace("__BASE_URL__", $BaseUrl)
Set-Content -LiteralPath $configTarget -Value $config -Encoding UTF8
Write-Host "Wrote: $configTarget"

Write-Step "Copying skills"
if (Test-Path -LiteralPath $skillsSrc) {
    Copy-Item -LiteralPath $skillsSrc -Destination (Join-Path $codexHome "skills") -Recurse -Force
    Write-Host "Copied skills to: $(Join-Path $codexHome "skills")"
} else {
    Write-Warning "No skills folder found in the install kit. Skipping."
}

Write-Step "Setting API key"
Write-Host "Create a separate API key for this PC in the proxy dashboard."
Write-Host "The key input will be hidden. Do not paste the key into any chat window."
$secureKey = Read-Host "Enter API Key" -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
try {
    $plainKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
} finally {
    if ($bstr -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}
if ([string]::IsNullOrWhiteSpace($plainKey)) {
    throw "API key is empty. Stopped."
}
$plainKey = $plainKey.Trim()
[Environment]::SetEnvironmentVariable("OPENAI_API_KEY", $plainKey, "User")
$env:OPENAI_API_KEY = $plainKey
Write-Host "Wrote user environment variable OPENAI_API_KEY."

Write-Step "Testing proxy models endpoint"
try {
    $headers = @{ Authorization = "Bearer $env:OPENAI_API_KEY" }
    $modelsUrl = "$($BaseUrl.TrimEnd('/'))/v1/models"
    $resp = Invoke-RestMethod -Uri $modelsUrl -Headers $headers -Method Get -TimeoutSec 30
    Write-Host "API test succeeded." -ForegroundColor Green
    if ($resp.data) {
        Write-Host "First models:"
        $resp.data | Select-Object -First 10 -ExpandProperty id
    }
} catch {
    Write-Warning "Model endpoint test failed. Check BaseUrl, API key, balance, and model access."
    Write-Warning $_.Exception.Message
}

Write-Step "Done"
Write-Host "Open or restart the Codex desktop app so the environment variable and config take effect." -ForegroundColor Green
