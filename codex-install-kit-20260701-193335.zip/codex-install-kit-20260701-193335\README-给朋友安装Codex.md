# 给朋友安装 Codex 的操作流程

这个安装包用于把当前电脑的 Codex 配置习惯和 skills 迁移到另一台 Windows 电脑。

## 重要提醒

- 不要把你的主 API Key 给别人。建议在中转站后台为对方单独创建 API Key。
- 这个包不包含你的登录态、API Key、历史记录、日志数据库。
- 这个包不包含剪映相关配置或剪映 skill。
- 通过第三方中转站使用模型时，提示词、代码片段、文件内容可能经过中转站服务器，请不要处理敏感资料。

## 你需要准备

1. 对方电脑主人同意你远程操作。
2. 对方电脑可以联网。
3. 中转站余额足够。
4. 中转站后台为对方创建好的 API Key。
5. 中转站 Base URL，默认是：

```text
https://nexus.1982video.cn
```

6. 中转站支持的模型 ID，当前模板默认：

```text
gpt-5.5
```

## 安装步骤

1. 用向日葵连接对方电脑。
2. 把整个 `codex-install-kit-...` 文件夹复制到对方电脑的非 C 盘，例如：

```text
D:\CodexInstallKit\
```

3. 在对方电脑上打开 PowerShell。
4. 进入安装包目录，例如：

```powershell
cd D:\CodexInstallKit\codex-install-kit-20260701-193335
```

5. 运行脚本：

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\Install-Codex-For-Friend.ps1
```

6. 脚本提示输入 API Key 时，粘贴对方专用 API Key。输入过程不会显示字符。
7. 脚本完成后，关闭并重新打开 Codex。

## 如果模型或地址不同

运行时可以指定：

```powershell
.\Install-Codex-For-Friend.ps1 -BaseUrl "https://nexus.1982video.cn" -Model "你的模型ID"
```

## 如果 winget 安装失败

有些电脑没有 winget，或者系统策略禁止自动安装。你可以先手动安装 Codex、Git、Node.js LTS，然后运行：

```powershell
.\Install-Codex-For-Friend.ps1 -SkipWingetInstall
```

## 出错时怎么问 Codex

把报错文字复制给 Codex，并说明：

```text
我在帮朋友安装 Codex，运行 D 盘安装包里的 Install-Codex-For-Friend.ps1 时出错。下面是报错，请帮我判断下一步怎么处理。
```

不要把 API Key 发给 Codex。
