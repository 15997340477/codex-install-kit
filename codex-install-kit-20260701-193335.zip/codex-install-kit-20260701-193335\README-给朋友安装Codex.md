# 给朋友安装 Codex 的操作流程

这个安装包用于把当前电脑的 Codex 配置习惯和 skills 迁移到另一台 Windows 电脑。

## 重要提醒

- 不要把你的主 API Key 给别人。建议在中转站后台为对方单独创建 API Key。
- 这个包不包含你的登录态、API Key、历史记录、日志数据库。
- 这个包不包含剪映相关配置或剪映 skill。
- 通过第三方中转站使用模型时，提示词、代码片段、文件内容可能经过中转站服务器，请不要处理敏感资料。

## 在线安装

把 `install-online.ps1` 和 zip 上传到可下载地址后，让对方在 PowerShell 运行你生成的一条命令即可。

脚本会把下载和解压临时文件放到系统临时目录。Codex 的用户配置会写入对方 Windows 用户目录下的 `.codex`，这是正常行为。

## 本地安装

如果不用在线命令，也可以把整个安装包文件夹复制到对方电脑任意位置，然后在 PowerShell 里运行：

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\Install-Codex-For-Friend.ps1
```

如果模型或地址不同，可以指定：

```powershell
.\Install-Codex-For-Friend.ps1 -BaseUrl "https://nexus.1982video.cn" -Model "你的模型ID"
```

如果 winget 安装失败，可以先手动安装 Codex、Git、Node.js LTS，然后运行：

```powershell
.\Install-Codex-For-Friend.ps1 -SkipWingetInstall
```

不要把 API Key 发给 Codex。脚本会在本机 PowerShell 里隐藏输入 API Key。
